package com.example.findany;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerviewAdapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<ModelClass> userdetails;

    private RecyclerviewAdapter(List<ModelClass> userdetails){
        this.userdetails=userdetails;
    }

    @NonNull
    @Override
    public RecyclerView.Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.studentprofileview,null);
        return new RecyclerView.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.Adapter.ViewHolder holder, int position) {

        int profile=userdetails.get(position).getProfileimage();
        String name=userdetails.get(position).getName();
        String year=userdetails.get(position).getYear();
        String branch=userdetails.get(position).getBranch();

        holder.setData(profile,name,year,branch);
    }

    @Override
    public int getItemCount() {
        return  userdetails.size();
    }
}
